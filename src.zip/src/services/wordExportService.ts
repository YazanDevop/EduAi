// src/services/wordExportService.ts

export function exportToWord(content: string) {
  console.log('Exporting to Word:', content);

  // مؤقت
  return true;
}
