import { GoogleGenAI, Type } from "@google/genai";
import { WorksheetContent } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateWorksheet = async (
  subject: string,
  semester: string,
  topic: string,
  style: string = 'creative'
): Promise<WorksheetContent> => {
  const prompt = `أنت خبير تربوي في المنهاج الفلسطيني للصف العاشر. صمم ورقة عمل احترافية وشاملة.
  المبحث: ${subject}
  الفصل الدراسي: ${semester}
  الموضوع: ${topic}
  النمط المطلوب: ${style} (إبداعي، رسمي، أو اختبار)

  يجب أن تتضمن ورقة العمل:
  1. أهداف تعليمية واضحة (2-3 أهداف).
  2. قسم للأسئلة المعرفية (اختيار من متعدد أو صح وخطأ).
  3. قسم للمهارات (حل مسائل، إكمال فراغات، أو تحليل نصوص).
  4. قسم للتفكير الناقد أو سؤال متميز.
  5. تعليمات للمعلم حول كيفية استخدام الورقة.
  6. نصيحة أو حكمة ختامية للطالب.

  تأكد من ملاءمة المحتوى للمستوى الأكاديمي للصف العاشر الفلسطيني.
  اجعل الأسئلة متنوعة وشيقة.`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          subject: { type: Type.STRING },
          semester: { type: Type.STRING },
          unit: { type: Type.STRING },
          learningObjectives: { type: Type.ARRAY, items: { type: Type.STRING } },
          sections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                type: { type: Type.STRING, enum: ['mcq', 'matching', 'short_answer', 'problem_solving', 'diagram'] },
                content: { type: Type.STRING },
                questions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      question: { type: Type.STRING },
                      options: { type: Type.ARRAY, items: { type: Type.STRING } },
                      answer: { type: Type.STRING },
                      points: { type: Type.NUMBER }
                    },
                    required: ["question", "points"]
                  }
                }
              },
              required: ["title", "type", "questions"]
            }
          },
          teacherInstructions: { type: Type.STRING },
          conclusion: { type: Type.STRING },
          style: { type: Type.STRING }
        },
        required: ["title", "subject", "semester", "learningObjectives", "sections", "teacherInstructions", "conclusion"]
      },
      thinkingConfig: { thinkingBudget: 15000 }
    }
  });

  return JSON.parse(response.text);
};