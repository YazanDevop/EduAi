import { WorksheetContent } from '../types';
import { SCHOOL_INFO } from '../constants';

export const exportToPDF = (content: WorksheetContent) => {
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;

  const html = `
    <html dir="rtl" lang="ar">
      <head>
        <title>ورقة عمل: ${content.title}</title>
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
        <style>
          @page { margin: 1cm; }
          body { font-family: 'Cairo', sans-serif; padding: 20px; color: #1a1a1a; line-height: 1.5; font-size: 14px; }
          .header-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; border-bottom: 2px solid #000; }
          .header-table td { padding: 10px; border: 1px solid #ddd; text-align: center; }
          .student-info { margin: 15px 0; font-weight: bold; border-bottom: 1px dashed #333; padding-bottom: 5px; }
          .section-title { background: #f3f4f6; padding: 5px 15px; border-right: 5px solid #333; margin: 20px 0 10px 0; font-weight: bold; font-size: 16px; }
          .question-box { margin-bottom: 15px; padding-right: 10px; }
          .points { font-size: 11px; color: #666; font-style: italic; }
          .options { display: flex; flex-wrap: wrap; gap: 20px; margin-top: 5px; list-style: none; padding: 0; }
          .answer-space { border-bottom: 1px dotted #ccc; height: 25px; margin: 5px 0 15px 0; width: 90%; }
          .footer { margin-top: 30px; border-top: 1px solid #000; padding-top: 10px; text-align: center; font-size: 12px; }
          @media print { .no-print { display: none; } }
        </style>
      </head>
      <body>
        <table class="header-table">
          <tr>
            <td width="30%">
              <strong>وزارة التربية والتعليم</strong><br>
              ${SCHOOL_INFO.school}<br>
              ${SCHOOL_INFO.location}
            </td>
            <td width="40%">
              <h2 style="margin:0">ورقة عمل تعليمية</h2>
              <strong>${content.title}</strong>
            </td>
            <td width="30%" style="text-align: right;">
              المبحث: ${content.subject}<br>
              الصف: ${SCHOOL_INFO.grade}<br>
              التاريخ: ..../..../202..م
            </td>
          </tr>
        </table>

        <div class="student-info">
          اسم الطالب/ة: ........................................................................................
        </div>

        <div style="margin-bottom: 20px;">
          <strong>🎯 الأهداف التعليمية:</strong>
          <ul style="margin: 5px 0;">
            ${content.learningObjectives.map(obj => `<li>${obj}</li>`).join('')}
          </ul>
        </div>

        ${content.sections.map((section, sIdx) => `
          <div class="section-title">${section.title}</div>
          ${section.questions.map((q, qIdx) => `
            <div class="question-box">
              <strong>${qIdx + 1}) ${q.question}</strong> <span class="points">(${q.points} علامات)</span>
              ${q.options ? `
                <ul class="options">
                  ${q.options.map(opt => `<li>( ) ${opt}</li>`).join('')}
                </ul>
              ` : `
                <div class="answer-space"></div>
                <div class="answer-space"></div>
              `}
            </div>
          `).join('')}
        `).join('')}

        <div class="footer">
          <p><em>${content.conclusion}</em></p>
          <div style="display:flex; justify-content: space-between; margin-top: 10px;">
            <span>إعداد المعلمة: ${SCHOOL_INFO.teacher}</span>
            <span>تمنياتي لكم بالتوفيق والإبداع</span>
          </div>
        </div>

        <script>
          window.onload = () => {
            window.print();
          };
        </script>
      </body>
    </html>
  `;

  printWindow.document.write(html);
  printWindow.document.close();
};