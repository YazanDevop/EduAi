import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell, WidthType, BorderStyle } from 'docx';
import { WorksheetContent } from '../types';
import { SCHOOL_INFO } from '../constants';

export const exportToWord = async (content: WorksheetContent) => {
  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: { top: 720, bottom: 720, left: 720, right: 720 },
          }
        },
        children: [
          // Header Table
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  new TableCell({
                    children: [
                      new Paragraph({ text: SCHOOL_INFO.school, alignment: AlignmentType.CENTER }),
                      new Paragraph({ text: "وزارة التربية والتعليم", alignment: AlignmentType.CENTER }),
                    ],
                  }),
                  new TableCell({
                    children: [
                      new Paragraph({ text: "ورقة عمل تعليمية", heading: HeadingLevel.HEADING_2, alignment: AlignmentType.CENTER }),
                      new Paragraph({ text: content.title, alignment: AlignmentType.CENTER, bold: true }),
                    ],
                  }),
                  new TableCell({
                    children: [
                      new Paragraph({ text: `المبحث: ${content.subject}`, alignment: AlignmentType.RIGHT }),
                      new Paragraph({ text: `الصف: ${SCHOOL_INFO.grade}`, alignment: AlignmentType.RIGHT }),
                      new Paragraph({ text: `التاريخ: ..../..../202..م`, alignment: AlignmentType.RIGHT }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          
          new Paragraph({ text: "", spacing: { before: 200 } }),
          
          new Paragraph({
            children: [
              new TextRun({ text: "اسم الطالب: ...........................................................................", bold: true }),
            ],
            alignment: AlignmentType.RIGHT,
          }),

          new Paragraph({ text: "--------------------------------------------------------------------------------------------------", alignment: AlignmentType.CENTER }),

          // Objectives
          new Paragraph({
            children: [new TextRun({ text: "الأهداف التعليمية:", bold: true, underline: {} })],
            alignment: AlignmentType.RIGHT,
            spacing: { before: 200, after: 100 },
          }),
          ...content.learningObjectives.map(obj => new Paragraph({ text: `• ${obj}`, alignment: AlignmentType.RIGHT })),

          // Sections
          ...content.sections.flatMap(section => [
            new Paragraph({
              children: [new TextRun({ text: section.title, bold: true, size: 28 })],
              alignment: AlignmentType.RIGHT,
              spacing: { before: 400, after: 200 },
            }),
            ...section.questions.flatMap((q, idx) => [
              new Paragraph({
                children: [
                  new TextRun({ text: `${idx + 1}) ${q.question}`, bold: true }),
                  new TextRun({ text: ` (${q.points} علامات)`, italic: true, size: 20 }),
                ],
                alignment: AlignmentType.RIGHT,
              }),
              ...(q.options ? [
                new Paragraph({
                  children: [new TextRun({ text: q.options.join("  |  ") })],
                  alignment: AlignmentType.RIGHT,
                  spacing: { before: 100 },
                })
              ] : [
                new Paragraph({ text: "الجواب: .........................................................................................................", alignment: AlignmentType.RIGHT, spacing: { before: 100 } }),
                new Paragraph({ text: "......................................................................................................................", alignment: AlignmentType.RIGHT })
              ])
            ])
          ]),

          new Paragraph({ text: "--------------------------------------------------------------------------------------------------", alignment: AlignmentType.CENTER, spacing: { before: 400 } }),
          
          new Paragraph({
            children: [new TextRun({ text: "بصمة المعلمة: ", bold: true }), new TextRun({ text: content.conclusion, italic: true })],
            alignment: AlignmentType.CENTER,
            spacing: { before: 200 },
          }),
          
          new Paragraph({
            text: `إعداد المعلمة: ${SCHOOL_INFO.teacher}`,
            alignment: AlignmentType.LEFT,
            spacing: { before: 200 },
          }),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `ورقة_عمل_${content.title}.docx`;
  link.click();
  URL.revokeObjectURL(url);
};